/**
 * Configuration management for the JS Client
 */
export class Config {
    constructor() {
        this.CLAUDE_API_KEY = localStorage.getItem('claude_api_key') || '';
        this.ZOHO_MCP_URL = localStorage.getItem('zoho_mcp_url') || '';
        this.CLAUDE_MODEL = "claude-sonnet-4-6";
    }

    save(apiKey, mcpUrl) {
        this.CLAUDE_API_KEY = apiKey;
        this.ZOHO_MCP_URL = mcpUrl;
        localStorage.setItem('claude_api_key', apiKey);
        localStorage.setItem('zoho_mcp_url', mcpUrl);
    }

    isValid() {
        return this.CLAUDE_API_KEY && this.ZOHO_MCP_URL;
    }
}
